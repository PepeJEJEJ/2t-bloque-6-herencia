public class Zonas {
    private String Nombre;
    private String Estado;
    private String Tipo;
    public Zonas(String Nombre,String Estado, String Tipo){
        this.Nombre=Nombre;
        this.Estado=Estado;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    public String getEstado() {
        return Estado;
    }
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }
    public String getTipo() {
        return Tipo;
    }
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }// VOLVAMOS AL VISUAL STUDIO CODE PORFA :'<
// Jose A.
    // Metodo como comentario por no funcionar
    /*    public reservar(){
    if (hora>1400 & hora<800) {
        System.out.println("Disponible");
        } else {
        System.out.println("NO Disponible");
        }
    return;
    }*/
    @Override
//To String no recuerdo como se escribe pero mientras demuestre que lo demas me lo se sin necesidad de nada ajeno, me sirve
}