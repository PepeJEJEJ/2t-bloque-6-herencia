public class Main {
    public static void main(String[] args) {
        Paciente paciente1=new Paciente("Godalba",241241,"Dolor Abdominal");
        Zona zona1=new Zona("Cardiologia","Disponible","Consulta");
    }
}
// VOLVAMOS AL VISUAL STUDIO CODE PORFA :'<

// Jose A. //pONGAME UN 5,6 Porfa