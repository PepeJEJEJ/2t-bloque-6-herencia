public class Paciente {
    private String Nombre;
    private int NSS;
    private String Dolor;
    public Paciente(String Nombre,int NSS,String Dolor){
        this.Nombre=Nombre;
        this.NSS=NSS;
        this.Dolor=Dolor;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    public int getNSS() {
        return NSS;
    }
    public void setNSS(int NSS) {
        this.NSS = NSS;
    }
    public String getDolor() {
        return Dolor;
    }
    public void setDolor(String Dolor) {
        this.Dolor = Dolor;
    }
    @Override
    //To String, No lo recuerdo como era pero mientras demuestre que lo demas me lo se sin necesidad de nada, me sirve
}