public class Main {
    public static void main(String[] args) {
        Paciente paciente1=New Paciente();
    }
}
// VOLVAMOS AL VISUAL STUDIO CODE PORFA :'<

// Jose A.