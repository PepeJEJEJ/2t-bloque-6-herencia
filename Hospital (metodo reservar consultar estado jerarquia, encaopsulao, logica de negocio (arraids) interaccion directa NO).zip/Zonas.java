public class Zonas {
    private String Nombre;
    private String Estado;
    private String Tipo;
    public Zonas(String Nombre,String Estado, String Tipo){
        this.Nombre=Nombre;
        this.Estado=Estado;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    public String getEstado() {
        return Estado;
    }
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }
    public String getTipo() {
        return Tipo;
    }
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
    public reservar(){
    if (hora>1400 & hora<800) {
        System.out.println("Disponible");
        } else {
        System.out.println("NO Disponible");
        }
    return;
    }
    @Override
//To String, No lo recuerdo como se escribe pero mientras demuestre que lo demas me lo se sin necesidad de nada ajeno, me sirve
}