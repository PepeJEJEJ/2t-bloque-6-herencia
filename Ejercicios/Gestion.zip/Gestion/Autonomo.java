package Gestion;

public class Autonomo extends Empresa {

    public Autonomo(String nombre, String cif) {
        super(nombre, cif);
    }
}